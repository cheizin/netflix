# Built with Ionic - Resources

The mockdata used for the Built with Ionic tutorials found on [Devdactic](https://devdactic.com).

Check out my eBook [Built with Ionic](https://builtwithionic.com/) for even more detailed examples!